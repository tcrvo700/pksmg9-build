/*
 *   This file is part of PKSM-Core
 *   Copyright (C) 2016-2022 Bernardo Giordano, Admiral Fish, piepie62, Pk11
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Additional Terms 7.b and 7.c of GPLv3 apply to this file:
 *       * Requiring preservation of specified reasonable legal notices or
 *         author attributions in that material or in the Appropriate Legal
 *         Notices displayed by works containing it.
 *       * Prohibiting misrepresentation of the origin of that material,
 *         or requiring that modified versions of such material be marked in
 *         reasonable ways as different from the original version.
 */

#include "utils/VersionTables.hpp"
#include "personal/personal.hpp"
#include "ppCount.hpp"
#include <algorithm>
#include <functional>

namespace
{
    template <typename T>
        requires std::is_enum_v<T> || std::integral<T> || requires { typename T::EnumType; }
    inline std::set<T> create_set_consecutive(const T& begin, const T& end)
    {
        std::set<T> set;
        if constexpr (std::is_integral_v<T>)
        {
            for (T i = begin; i <= end; i++)
            {
                set.insert(i);
            }
        }
        else if constexpr (std::is_enum_v<T>)
        {
            using INT = std::underlying_type_t<T>;
            for (INT i = INT(begin); i <= INT(end); i++)
            {
                set.insert(T(i));
            }
        }
        else
        {
            using INT = std::underlying_type_t<typename T::EnumType>;
            for (INT i = INT(begin); i <= INT(end); i++)
            {
                set.insert(T(i));
            }
        }
        return set;
    }

    // Build a Move set from a consecutive range, excluding dummied moves marked in a bitflag array.
    // Bit set (1) = move is dummied/invalid.
    inline std::set<pksm::Move> create_set_excluding_dummied(
        pksm::Move maxMove, const u8* dummied, size_t dummiedSize)
    {
        std::set<pksm::Move> set;
        for (u16 i = 0; i <= u16(maxMove); i++)
        {
            size_t byteIdx = i >> 3;
            u8 bitIdx      = i & 7;
            bool isDummied = (byteIdx < dummiedSize) && ((dummied[byteIdx] & (1 << bitIdx)) != 0);
            if (!isDummied)
            {
                set.insert(pksm::Move{i});
            }
        }
        return set;
    }

    // Dummied-move bitflag arrays, one bit per move ID
    // Bit set = move is dummied (not usable in that game)

    // SWSH (Gen 8)
    constexpr u8 DummiedMoves_SWSH[] = {
        0x1C,
        0x20,
        0x00,
        0x0C,
        0x00,
        0x02,
        0x02,
        0x00,
        0x00,
        0x00,
        0x04,
        0x00,
        0x09,
        0x00,
        0xA1,
        0x22,
        0x19,
        0x10,
        0x36,
        0xC0,
        0x40,
        0x0A,
        0x00,
        0x02,
        0x02,
        0x00,
        0x00,
        0x45,
        0x10,
        0x20,
        0x00,
        0x00,
        0x00,
        0x02,
        0x04,
        0x80,
        0x66,
        0x70,
        0x00,
        0x50,
        0x91,
        0x00,
        0x00,
        0x04,
        0x64,
        0x08,
        0x20,
        0x67,
        0x84,
        0x00,
        0x00,
        0x00,
        0x00,
        0xA4,
        0x00,
        0x28,
        0x03,
        0x01,
        0x07,
        0x20,
        0x22,
        0x00,
        0x04,
        0x08,
        0x10,
        0x00,
        0x08,
        0x02,
        0x08,
        0x00,
        0x08,
        0x02,
        0x00,
        0x00,
        0x02,
        0x01,
        0x00,
        0xE2,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0x07,
        0x82,
        0x01,
        0x40,
        0x84,
        0xFF,
        0x00,
        0x80,
        0xF8,
        0xFF,
        0x3F,
    };

    // PLA (Gen 8a)
    constexpr u8 DummiedMoves_PLA[] = {
        0x7E,
        0xBC,
        0xFE,
        0xFF,
        0xBD,
        0xEA,
        0xCF,
        0x72,
        0x7F,
        0x1F,
        0x0E,
        0x1F,
        0xAB,
        0xFD,
        0xEF,
        0xBE,
        0x7D,
        0xD7,
        0x35,
        0xCF,
        0xD5,
        0xEF,
        0x5F,
        0x0F,
        0xEF,
        0x9E,
        0xFD,
        0xFF,
        0x7E,
        0x5F,
        0x3B,
        0xFD,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xDF,
        0xBF,
        0xB3,
        0xBF,
        0xAF,
        0xF5,
        0xE4,
        0xF6,
        0xFF,
        0xFB,
        0xFF,
        0xFF,
        0x2B,
        0x84,
        0x8C,
        0x08,
        0xA0,
        0xDB,
        0xAA,
        0xC5,
        0x21,
        0xF0,
        0xFB,
        0xFF,
        0xF7,
        0xFF,
        0xFB,
        0xFF,
        0xF3,
        0xFE,
        0xBF,
        0xFF,
        0xE7,
        0xFF,
        0xFF,
        0x7D,
        0xFC,
        0xF7,
        0xDF,
        0xFE,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xB7,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xBF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xEF,
        0xFF,
        0xFF,
        0xFF,
        0x07,
    };

    // SV (Gen 9)
    constexpr u8 DummiedMoves_SV[] = {
        0x1C,
        0x20,
        0x00,
        0x0C,
        0x00,
        0x02,
        0x02,
        0x00,
        0x04,
        0x00,
        0x04,
        0x00,
        0x09,
        0x00,
        0xA1,
        0x22,
        0x5D,
        0x50,
        0x36,
        0xC8,
        0x00,
        0x0E,
        0x00,
        0x42,
        0x02,
        0x00,
        0x00,
        0x45,
        0x10,
        0x22,
        0x00,
        0x00,
        0x04,
        0x0A,
        0xA4,
        0x80,
        0x27,
        0x70,
        0x00,
        0x51,
        0x91,
        0x00,
        0x00,
        0x04,
        0x60,
        0x08,
        0xA0,
        0x67,
        0x04,
        0x00,
        0x00,
        0x00,
        0x00,
        0xA4,
        0x00,
        0x28,
        0x01,
        0x01,
        0x04,
        0x28,
        0x23,
        0x00,
        0x04,
        0x08,
        0x10,
        0x00,
        0x0C,
        0x83,
        0x07,
        0x00,
        0x8A,
        0x02,
        0x4C,
        0x10,
        0x80,
        0x03,
        0xF0,
        0xC3,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0x07,
        0x80,
        0x26,
        0xA0,
        0x80,
        0xFF,
        0x11,
        0xE1,
        0xFB,
        0xFF,
        0xFF,
        0x00,
        0xEE,
        0xFF,
        0x7F,
        0x08,
        0x00,
        0x0D,
    };

    // Z-A (Gen 9a)
    constexpr u8 DummiedMoves_ZA[] = {
        0x2E,
        0x9C,
        0xB0,
        0xDF,
        0x29,
        0x02,
        0x0E,
        0x40,
        0x7E,
        0x01,
        0x04,
        0x00,
        0x29,
        0xC8,
        0xA1,
        0x3A,
        0xD9,
        0x59,
        0x37,
        0xD5,
        0xE0,
        0xAF,
        0x3E,
        0x6F,
        0xC6,
        0x02,
        0xF5,
        0x77,
        0x7C,
        0x62,
        0x1B,
        0xE8,
        0x55,
        0xCF,
        0xFD,
        0xFA,
        0x7F,
        0xF4,
        0xE4,
        0x15,
        0xDF,
        0x80,
        0xC1,
        0xA4,
        0xFE,
        0xFF,
        0xF9,
        0xFD,
        0xBF,
        0x2A,
        0x02,
        0x80,
        0x08,
        0xA4,
        0x83,
        0xA1,
        0xC7,
        0x79,
        0xFA,
        0xFD,
        0xEA,
        0xF2,
        0x7F,
        0xDF,
        0xFF,
        0x25,
        0x48,
        0xAB,
        0xE3,
        0xE7,
        0x2E,
        0x13,
        0x7C,
        0x68,
        0xA0,
        0xDD,
        0x05,
        0xC0,
        0xFF,
        0xFF,
        0xFF,
        0xFF,
        0xE7,
        0x9D,
        0x7F,
        0x7F,
        0xDF,
        0xFF,
        0xA9,
        0xFE,
        0xFD,
        0xFF,
        0xBF,
        0xEF,
        0xFD,
        0xFF,
        0xFF,
        0x7F,
        0xFA,
        0x6B,
        0xFE,
        0x0F,
        0xFF,
        0xBF,
        0x7F,
        0xFF,
        0xBF,
        0xBA,
        0xFA,
        0xFB,
        0x9E,
        0xD1,
        0xFF,
        0xFF,
        0xFF,
    };
}

namespace pksm
{
    const std::set<int>& VersionTables::availableItems(GameVersion version)
    {
        static const std::set<int> emptySet;
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
            {
                static const std::set<int> items = {0, 1, 2, 3, 4, 5, 6, 10, 11, 12, 13, 14, 15, 16,
                    17, 18, 19, 20, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 45,
                    46, 47, 48, 49, 51, 52, 53, 54, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 67,
                    68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 196, 197, 198,
                    199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214,
                    215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230,
                    231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246,
                    247, 248, 249, 250};
                return items;
            }
            case GameVersion::GD:
            case GameVersion::SV:
            {
                static const std::set<int> items = {0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14,
                    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
                    36, 37, 38, 39, 40, 41, 42, 43, 44, 46, 47, 48, 49, 51, 52, 53, 54, 55, 57, 58,
                    59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 72, 73, 74, 75, 76, 77, 78, 79,
                    80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99, 101,
                    102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 117, 118, 119,
                    121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134, 138, 139, 140,
                    143, 144, 146, 150, 151, 152, 156, 157, 158, 159, 160, 161, 163, 164, 165, 166,
                    167, 168, 169, 170, 172, 173, 174, 175, 178, 180, 181, 182, 183, 184, 185, 186,
                    187, 188, 189, 191, 192, 193, 194, 196, 197, 198, 199, 200, 201, 202, 203, 204,
                    205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 221,
                    222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237,
                    238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249};
                return items;
            }
            case GameVersion::C:
            {
                static const std::set<int> items = {0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14,
                    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
                    36, 37, 38, 39, 40, 41, 42, 43, 44, 46, 47, 48, 49, 51, 52, 53, 54, 55, 57, 58,
                    59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78,
                    79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99,
                    101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116,
                    117, 118, 119, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133,
                    134, 138, 139, 140, 143, 144, 146, 150, 151, 152, 156, 157, 158, 159, 160, 161,
                    163, 164, 165, 166, 167, 168, 169, 170, 172, 173, 174, 175, 178, 180, 181, 182,
                    183, 184, 185, 186, 187, 188, 189, 191, 192, 193, 194, 196, 197, 198, 199, 200,
                    201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216,
                    217, 218, 219, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233,
                    234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249};
                return items;
            }
            case GameVersion::R:
            case GameVersion::S:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 348); });
                return items;
            }
            case GameVersion::FR:
            case GameVersion::LG:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 374); });
                return items;
            }
            case GameVersion::E:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 376); });
                return items;
            }
            case GameVersion::D:
            case GameVersion::P:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 464); });
                return items;
            }
            case GameVersion::Pt:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 467); });
                return items;
            }
            case GameVersion::HG:
            case GameVersion::SS:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 536); });
                return items;
            }
            case GameVersion::B:
            case GameVersion::W:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 632); });
                return items;
            }
            case GameVersion::B2:
            case GameVersion::W2:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 638); });
                return items;
            }
            case GameVersion::X:
            case GameVersion::Y:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 717); });
                return items;
            }
            case GameVersion::OR:
            case GameVersion::AS:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 775); });
                return items;
            }
            case GameVersion::SN:
            case GameVersion::MN:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 920); });
                return items;
            }
            case GameVersion::US:
            case GameVersion::UM:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 1023); });
                return items;
            }
            case GameVersion::GE:
            case GameVersion::GP:
            {
                static const std::set<int> items = {0, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
                    28, 29, 30, 31, 32, 38, 39, 40, 41, 709, 903, 328, 329, 330, 331, 332, 333, 334,
                    335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350,
                    351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366,
                    367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382,
                    383, 384, 385, 386, 387, 50, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969,
                    970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 985,
                    986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000,
                    1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013,
                    1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026,
                    1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039,
                    1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052,
                    1053, 1054, 1055, 1056, 1057, 51, 53, 81, 82, 83, 84, 85, 849, 1, 2, 3, 4, 12,
                    164, 166, 168, 861, 862, 863, 864, 865, 866, 55, 56, 57, 58, 59, 60, 61, 62,
                    656, 659, 660, 661, 662, 663, 671, 672, 675, 676, 678, 679, 760, 762, 770, 773,
                    76, 77, 78, 79, 86, 87, 88, 89, 90, 91, 92, 93, 101, 102, 103, 113, 115, 121,
                    122, 123, 124, 125, 126, 127, 128, 442, 571, 632, 651, 795, 796, 872, 873, 874,
                    875, 876, 877, 878, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896,
                    900, 901, 902};
                return items;
            }
            case GameVersion::SW:
            case GameVersion::SH:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 1607); });
                return items;
            }
            case GameVersion::PLA:
            {
                static const std::set<int> items = {
                    // Normal Items and PC Items
                    17,
                    23,
                    24,
                    25,
                    26,
                    27,
                    28,
                    29,
                    39,
                    41,
                    50,
                    54,
                    72,
                    73,
                    75,
                    80,
                    81,
                    82,
                    83,
                    84,
                    85,
                    90,
                    91,
                    92,
                    107,
                    108,
                    109,
                    110,
                    149,
                    150,
                    151,
                    152,
                    153,
                    154,
                    155,
                    157,
                    158,
                    159,
                    160,
                    161,
                    162,
                    163,
                    164,
                    166,
                    168,
                    233,
                    252,
                    321,
                    322,
                    323,
                    324,
                    325,
                    326,
                    327,
                    583,
                    849,
                    1125,
                    1126,
                    1127,
                    1128,
                    1231,
                    1232,
                    1233,
                    1234,
                    1235,
                    1236,
                    1237,
                    1238,
                    1239,
                    1240,
                    1241,
                    1242,
                    1243,
                    1244,
                    1245,
                    1246,
                    1247,
                    1248,
                    1249,
                    1250,
                    1251,
                    1611,
                    1613,
                    1614,
                    1615,
                    1616,
                    1617,
                    1618,
                    1619,
                    1620,
                    1621,
                    1628,
                    1630,
                    1631,
                    1632,
                    1633,
                    1634,
                    1635,
                    1636,
                    1637,
                    1638,
                    1651,
                    1679,
                    1681,
                    1682,
                    1684,
                    1686,
                    1687,
                    1688,
                    1689,
                    1690,
                    1691,
                    1692,
                    1693,
                    1694,
                    1695,
                    1696,
                    1699,
                    1700,
                    1701,
                    1702,
                    1703,
                    1704,
                    1705,
                    1706,
                    1707,
                    1708,
                    1709,
                    1710,
                    1711,
                    1712,
                    1713,
                    1716,
                    1717,
                    1720,
                    1724,
                    1725,
                    1726,
                    1727,
                    1728,
                    1732,
                    1733,
                    1734,
                    1735,
                    1736,
                    1738,
                    1739,
                    1740,
                    1741,
                    1742,
                    1746,
                    1747,
                    1748,
                    1749,
                    1750,
                    1754,
                    1755,
                    1756,
                    1757,
                    1758,
                    1759,
                    1760,
                    1761,
                    1762,
                    1764,
                    1785,
                    // Key Items
                    111,
                    298,
                    299,
                    300,
                    301,
                    302,
                    303,
                    304,
                    305,
                    306,
                    307,
                    308,
                    309,
                    310,
                    311,
                    312,
                    313,
                    441,
                    455,
                    466,
                    632,
                    638,
                    644,
                    1608,
                    1609,
                    1610,
                    1612,
                    1622,
                    1624,
                    1625,
                    1626,
                    1627,
                    1629,
                    1639,
                    1678,
                    1721,
                    1722,
                    1723,
                    1737,
                    1743,
                    1744,
                    1745,
                    1763,
                    1765,
                    1766,
                    1767,
                    1768,
                    1769,
                    1771,
                    1776,
                    1777,
                    1778,
                    1779,
                    1780,
                    1782,
                    1786,
                    1787,
                    1788,
                    1789,
                    1790,
                    1792,
                    1793,
                    1794,
                    1795,
                    1796,
                    1797,
                    1798,
                    1799,
                    1800,
                    1801,
                    1802,
                    1803,
                    1804,
                    1805,
                    1806,
                    1807,
                    1828,
                };
                return items;
            }
            case GameVersion::SL:
            case GameVersion::VL:
            {
                static const std::set<int> items =
                    std::invoke([]() { return create_set_consecutive<int>(0, 2557); });
                return items;
            }
            case GameVersion::ZA:
            {
                static const std::set<int> items = {
                    // Medicine
                    17,
                    18,
                    19,
                    20,
                    21,
                    22,
                    23,
                    24,
                    25,
                    26,
                    27,
                    28,
                    29,
                    30,
                    31,
                    32,
                    33,
                    708,
                    2684,
                    // Balls
                    1,
                    2,
                    3,
                    4,
                    5,
                    6,
                    7,
                    8,
                    9,
                    10,
                    11,
                    12,
                    13,
                    14,
                    15,
                    16,
                    492,
                    493,
                    494,
                    495,
                    496,
                    497,
                    498,
                    499,
                    576,
                    851,
                    // Other (Items)
                    45,
                    46,
                    47,
                    48,
                    49,
                    50,
                    52,
                    80,
                    81,
                    82,
                    83,
                    84,
                    85,
                    103,
                    107,
                    108,
                    109,
                    116,
                    117,
                    118,
                    119,
                    214,
                    217,
                    218,
                    221,
                    222,
                    230,
                    231,
                    232,
                    233,
                    234,
                    236,
                    237,
                    238,
                    239,
                    240,
                    241,
                    242,
                    243,
                    244,
                    245,
                    246,
                    247,
                    248,
                    249,
                    250,
                    251,
                    252,
                    253,
                    258,
                    259,
                    266,
                    267,
                    268,
                    270,
                    275,
                    289,
                    290,
                    291,
                    292,
                    293,
                    294,
                    296,
                    324,
                    534,
                    535,
                    537,
                    538,
                    540,
                    564,
                    565,
                    566,
                    567,
                    568,
                    569,
                    570,
                    639,
                    640,
                    646,
                    647,
                    710,
                    711,
                    795,
                    796,
                    849,
                    1124,
                    1125,
                    1126,
                    1127,
                    1128,
                    1231,
                    1232,
                    1233,
                    1234,
                    1235,
                    1236,
                    1237,
                    1238,
                    1239,
                    1240,
                    1241,
                    1242,
                    1243,
                    1244,
                    1245,
                    1246,
                    1247,
                    1248,
                    1249,
                    1250,
                    1251,
                    1582,
                    1592,
                    1691,
                    1861,
                    2137,
                    2344,
                    2401,
                    2558,
                    2618,
                    2619,
                    // Treasure
                    86,
                    88,
                    89,
                    92,
                    571,
                    581,
                    582,
                    // Key Items
                    632,
                    700,
                    765,
                    847,
                    1278,
                    2588,
                    2589,
                    2590,
                    2591,
                    2592,
                    2595,
                    2596,
                    2597,
                    2598,
                    2599,
                    2600,
                    2601,
                    2602,
                    2603,
                    2604,
                    2605,
                    2606,
                    2607,
                    2608,
                    2609,
                    2610,
                    2611,
                    2612,
                    2613,
                    2620,
                    2621,
                    2622,
                    2623,
                    2624,
                    2625,
                    2626,
                    2627,
                    2628,
                    2629,
                    2630,
                    2631,
                    2632,
                    2633,
                    2634,
                    // Berries
                    149,
                    150,
                    151,
                    152,
                    153,
                    155,
                    156,
                    157,
                    158,
                    169,
                    170,
                    171,
                    172,
                    173,
                    174,
                    184,
                    185,
                    186,
                    187,
                    188,
                    189,
                    190,
                    191,
                    192,
                    193,
                    194,
                    195,
                    196,
                    197,
                    198,
                    199,
                    200,
                    686,
                    2651,
                    2652,
                    2653,
                    2654,
                    2655,
                    2656,
                    2657,
                    2658,
                    2659,
                    2660,
                    2661,
                    2662,
                    2663,
                    2664,
                    2665,
                    2666,
                    2667,
                    2668,
                    2669,
                    2670,
                    2671,
                    2672,
                    2673,
                    2674,
                    2675,
                    2676,
                    2677,
                    2678,
                    2679,
                    2680,
                    2681,
                    2682,
                    2683,
                    // TMs
                    328,
                    329,
                    330,
                    331,
                    332,
                    333,
                    334,
                    335,
                    336,
                    337,
                    338,
                    339,
                    340,
                    341,
                    342,
                    343,
                    344,
                    345,
                    346,
                    347,
                    348,
                    349,
                    350,
                    351,
                    352,
                    353,
                    354,
                    355,
                    356,
                    357,
                    358,
                    359,
                    360,
                    361,
                    362,
                    363,
                    364,
                    365,
                    366,
                    367,
                    368,
                    369,
                    370,
                    371,
                    372,
                    373,
                    374,
                    375,
                    376,
                    377,
                    378,
                    379,
                    380,
                    381,
                    382,
                    383,
                    384,
                    385,
                    386,
                    387,
                    388,
                    389,
                    390,
                    391,
                    392,
                    393,
                    394,
                    395,
                    396,
                    397,
                    398,
                    399,
                    400,
                    401,
                    402,
                    403,
                    404,
                    405,
                    406,
                    407,
                    408,
                    409,
                    410,
                    411,
                    412,
                    413,
                    414,
                    415,
                    416,
                    417,
                    418,
                    419,
                    618,
                    619,
                    620,
                    690,
                    691,
                    692,
                    693,
                    2160,
                    2162,
                    2163,
                    2164,
                    2165,
                    2166,
                    2167,
                    2168,
                    2169,
                    2170,
                    2171,
                    2172,
                    2173,
                    2174,
                    2175,
                    2176,
                    2177,
                    2178,
                    2179,
                    2180,
                    2181,
                    2182,
                    2183,
                    2184,
                    2185,
                    2186,
                    2187,
                    2188,
                    2189,
                    2190,
                    2191,
                    2192,
                    2193,
                    2194,
                    2195,
                    2196,
                    2197,
                    2198,
                    2199,
                    2200,
                    2201,
                    2202,
                    2203,
                    2204,
                    2205,
                    2206,
                    2207,
                    2208,
                    2209,
                    2210,
                    2211,
                    2212,
                    2213,
                    2214,
                    2215,
                    2216,
                    2217,
                    2218,
                    2219,
                    2220,
                    2221,
                    // Mega Stones
                    656,
                    657,
                    658,
                    659,
                    660,
                    661,
                    662,
                    663,
                    664,
                    665,
                    666,
                    667,
                    668,
                    669,
                    670,
                    671,
                    672,
                    673,
                    674,
                    675,
                    676,
                    677,
                    678,
                    679,
                    680,
                    681,
                    682,
                    683,
                    684,
                    685,
                    752,
                    753,
                    754,
                    755,
                    756,
                    757,
                    758,
                    759,
                    760,
                    761,
                    762,
                    763,
                    764,
                    767,
                    768,
                    769,
                    770,
                    2559,
                    2560,
                    2561,
                    2562,
                    2563,
                    2564,
                    2565,
                    2566,
                    2567,
                    2568,
                    2569,
                    2570,
                    2571,
                    2572,
                    2573,
                    2574,
                    2575,
                    2576,
                    2577,
                    2578,
                    2579,
                    2580,
                    2581,
                    2582,
                    2583,
                    2584,
                    2585,
                    2586,
                    2587,
                    2635,
                    2636,
                    2637,
                    2638,
                    2639,
                    2640,
                    2641,
                    2642,
                    2643,
                    2644,
                    2645,
                    2646,
                    2647,
                    2648,
                    2649,
                    2650,
                };
                return items;
            }
            default:
                return emptySet;
        }
    }

    const std::set<Move>& VersionTables::availableMoves(GameVersion version)
    {
        static const std::set<Move> emptySet;
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::Struggle); });
                return items;
            }
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::BeatUp); });
                return items;
            }
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::PsychoBoost); });
                return items;
            }
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::ShadowForce); });
                return items;
            }
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::FusionBolt); });
                return items;
            }
            case GameVersion::X:
            case GameVersion::Y:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::LightofRuin); });
                return items;
            }
            case GameVersion::OR:
            case GameVersion::AS:
            {
                static const std::set<Move> items = std::invoke([]()
                    { return create_set_consecutive<Move>(Move::None, Move::HyperspaceFury); });
                return items;
            }
            case GameVersion::SN:
            case GameVersion::MN:
            {
                static const std::set<Move> items = std::invoke(
                    []() { return create_set_consecutive<Move>(Move::None, Move::MindBlown); });
                return items;
            }
            case GameVersion::US:
            case GameVersion::UM:
            {
                static const std::set<Move> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Move>(Move::None, Move::NihilLight);
                    });
                return items;
            }
            case GameVersion::GE:
            case GameVersion::GP:
            {
                static const std::set<Move> items = {Move::None, Move::Pound, Move::KarateChop,
                    Move::DoubleSlap, Move::CometPunch, Move::MegaPunch, Move::PayDay,
                    Move::FirePunch, Move::IcePunch, Move::ThunderPunch, Move::Scratch,
                    Move::ViseGrip, Move::Guillotine, Move::RazorWind, Move::SwordsDance, Move::Cut,
                    Move::Gust, Move::WingAttack, Move::Whirlwind, Move::Fly, Move::Bind,
                    Move::Slam, Move::VineWhip, Move::Stomp, Move::DoubleKick, Move::MegaKick,
                    Move::JumpKick, Move::RollingKick, Move::SandAttack, Move::Headbutt,
                    Move::HornAttack, Move::FuryAttack, Move::HornDrill, Move::Tackle,
                    Move::BodySlam, Move::Wrap, Move::TakeDown, Move::Thrash, Move::DoubleEdge,
                    Move::TailWhip, Move::PoisonSting, Move::Twineedle, Move::PinMissile,
                    Move::Leer, Move::Bite, Move::Growl, Move::Roar, Move::Sing, Move::Supersonic,
                    Move::SonicBoom, Move::Disable, Move::Acid, Move::Ember, Move::Flamethrower,
                    Move::Mist, Move::WaterGun, Move::HydroPump, Move::Surf, Move::IceBeam,
                    Move::Blizzard, Move::Psybeam, Move::BubbleBeam, Move::AuroraBeam,
                    Move::HyperBeam, Move::Peck, Move::DrillPeck, Move::Submission, Move::LowKick,
                    Move::Counter, Move::SeismicToss, Move::Strength, Move::Absorb, Move::MegaDrain,
                    Move::LeechSeed, Move::Growth, Move::RazorLeaf, Move::SolarBeam,
                    Move::PoisonPowder, Move::StunSpore, Move::SleepPowder, Move::PetalDance,
                    Move::StringShot, Move::DragonRage, Move::FireSpin, Move::ThunderShock,
                    Move::Thunderbolt, Move::ThunderWave, Move::Thunder, Move::RockThrow,
                    Move::Earthquake, Move::Fissure, Move::Dig, Move::Toxic, Move::Confusion,
                    Move::Psychic, Move::Hypnosis, Move::Meditate, Move::Agility, Move::QuickAttack,
                    Move::Rage, Move::Teleport, Move::NightShade, Move::Mimic, Move::Screech,
                    Move::DoubleTeam, Move::Recover, Move::Harden, Move::Minimize,
                    Move::Smokescreen, Move::ConfuseRay, Move::Withdraw, Move::DefenseCurl,
                    Move::Barrier, Move::LightScreen, Move::Haze, Move::Reflect, Move::FocusEnergy,
                    Move::Bide, Move::Metronome, Move::MirrorMove, Move::SelfDestruct,
                    Move::EggBomb, Move::Lick, Move::Smog, Move::Sludge, Move::BoneClub,
                    Move::FireBlast, Move::Waterfall, Move::Clamp, Move::Swift, Move::SkullBash,
                    Move::SpikeCannon, Move::Constrict, Move::Amnesia, Move::Kinesis,
                    Move::SoftBoiled, Move::HighJumpKick, Move::Glare, Move::DreamEater,
                    Move::PoisonGas, Move::Barrage, Move::LeechLife, Move::LovelyKiss,
                    Move::SkyAttack, Move::Transform, Move::Bubble, Move::DizzyPunch, Move::Spore,
                    Move::Flash, Move::Psywave, Move::Splash, Move::AcidArmor, Move::Crabhammer,
                    Move::Explosion, Move::FurySwipes, Move::Bonemerang, Move::Rest,
                    Move::RockSlide, Move::HyperFang, Move::Sharpen, Move::Conversion,
                    Move::TriAttack, Move::SuperFang, Move::Slash, Move::Substitute, Move::Protect,
                    Move::SludgeBomb, Move::Outrage, Move::Megahorn, Move::Encore, Move::IronTail,
                    Move::Crunch, Move::MirrorCoat, Move::ShadowBall, Move::FakeOut, Move::HeatWave,
                    Move::WillOWisp, Move::Facade, Move::Taunt, Move::HelpingHand, Move::Superpower,
                    Move::BrickBreak, Move::Yawn, Move::BulkUp, Move::CalmMind, Move::Roost,
                    Move::Feint, Move::Uturn, Move::SuckerPunch, Move::FlareBlitz, Move::PoisonJab,
                    Move::DarkPulse, Move::AirSlash, Move::XScissor, Move::BugBuzz,
                    Move::DragonPulse, Move::NastyPlot, Move::IceShard, Move::FlashCannon,
                    Move::PowerWhip, Move::StealthRock, Move::AquaJet, Move::QuiverDance,
                    Move::FoulPlay, Move::ClearSmog, Move::Scald, Move::ShellSmash,
                    Move::DragonTail, Move::DrillRun, Move::PlayRough, Move::Moonblast,
                    Move::HappyHour, Move::DazzlingGleam, Move::Celebrate, Move::HoldHands,
                    Move::ZippyZap, Move::SplishySplash, Move::FloatyFall, Move::BouncyBubble,
                    Move::BuzzyBuzz, Move::SizzlySlide, Move::GlitzyGlow, Move::BaddyBad,
                    Move::SappySeed, Move::FreezyFrost, Move::SparklySwirl, Move::DoubleIronBash};
                return items;
            }
            case GameVersion::SW:
            case GameVersion::SH:
            {
                static const std::set<Move> items = std::invoke(
                    []()
                    {
                        return create_set_excluding_dummied(
                            Move::EerieSpell, DummiedMoves_SWSH, sizeof(DummiedMoves_SWSH));
                    });
                return items;
            }
            case GameVersion::PLA:
            {
                static const std::set<Move> items = std::invoke(
                    []()
                    {
                        return create_set_excluding_dummied(
                            Move::TakeHeart, DummiedMoves_PLA, sizeof(DummiedMoves_PLA));
                    });
                return items;
            }
            case GameVersion::SL:
            case GameVersion::VL:
            {
                static const std::set<Move> items = std::invoke(
                    []()
                    {
                        return create_set_excluding_dummied(
                            Move::MalignantChain, DummiedMoves_SV, sizeof(DummiedMoves_SV));
                    });
                return items;
            }
            case GameVersion::ZA:
            {
                static const std::set<Move> items = std::invoke(
                    []()
                    {
                        return create_set_excluding_dummied(
                            Move::NihilLight, DummiedMoves_ZA, sizeof(DummiedMoves_ZA));
                    });
                return items;
            }
            default:
                return emptySet;
        }
    }

    const std::set<Species>& VersionTables::availableSpecies(GameVersion version)
    {
        static const std::set<Species> emptySet;
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
            {
                static const std::set<Species> items = std::invoke([]()
                    { return create_set_consecutive<Species>(Species::Bulbasaur, Species::Mew); });
                return items;
            }
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(Species::Bulbasaur, Species::Celebi);
                    });
                return items;
            }
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(Species::Bulbasaur, Species::Deoxys);
                    });
                return items;
            }
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(Species::Bulbasaur, Species::Arceus);
                    });
                return items;
            }
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(
                            Species::Bulbasaur, Species::Genesect);
                    });
                return items;
            }
            case GameVersion::X:
            case GameVersion::Y:
            case GameVersion::OR:
            case GameVersion::AS:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(
                            Species::Bulbasaur, Species::Volcanion);
                    });
                return items;
            }
            case GameVersion::SN:
            case GameVersion::MN:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(
                            Species::Bulbasaur, Species::Marshadow);
                    });
                return items;
            }
            case GameVersion::US:
            case GameVersion::UM:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Species>(
                            Species::Bulbasaur, Species::Pecharunt);
                    });
                return items;
            }
            case GameVersion::GE:
            case GameVersion::GP:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        auto ret =
                            create_set_consecutive<Species>(Species::Bulbasaur, Species::Mew);
                        ret.emplace(Species::Meltan);
                        ret.emplace(Species::Melmetal);
                        return ret;
                    });
                return items;
            }
            case GameVersion::SW:
            case GameVersion::SH:
            {
                static const std::set<Species> items = {Species::Bulbasaur, Species::Ivysaur,
                    Species::Venusaur, Species::Charmander, Species::Charmeleon, Species::Charizard,
                    Species::Squirtle, Species::Wartortle, Species::Blastoise, Species::Caterpie,
                    Species::Metapod, Species::Butterfree, Species::Pikachu, Species::Raichu,
                    Species::Clefairy, Species::Clefable, Species::Vulpix, Species::Ninetales,
                    Species::Oddish, Species::Gloom, Species::Vileplume, Species::Diglett,
                    Species::Dugtrio, Species::Meowth, Species::Persian, Species::Growlithe,
                    Species::Arcanine, Species::Machop, Species::Machoke, Species::Machamp,
                    Species::Ponyta, Species::Rapidash, Species::Farfetchd, Species::Shellder,
                    Species::Cloyster, Species::Gastly, Species::Haunter, Species::Gengar,
                    Species::Onix, Species::Krabby, Species::Kingler, Species::Hitmonlee,
                    Species::Hitmonchan, Species::Koffing, Species::Weezing, Species::Rhyhorn,
                    Species::Rhydon, Species::Goldeen, Species::Seaking, Species::MrMime,
                    Species::Magikarp, Species::Gyarados, Species::Lapras, Species::Ditto,
                    Species::Eevee, Species::Vaporeon, Species::Jolteon, Species::Flareon,
                    Species::Snorlax, Species::Mewtwo, Species::Mew, Species::Hoothoot,
                    Species::Noctowl, Species::Chinchou, Species::Lanturn, Species::Pichu,
                    Species::Cleffa, Species::Togepi, Species::Togetic, Species::Natu,
                    Species::Xatu, Species::Bellossom, Species::Sudowoodo, Species::Wooper,
                    Species::Quagsire, Species::Espeon, Species::Umbreon, Species::Wobbuffet,
                    Species::Steelix, Species::Qwilfish, Species::Shuckle, Species::Sneasel,
                    Species::Swinub, Species::Piloswine, Species::Corsola, Species::Remoraid,
                    Species::Octillery, Species::Delibird, Species::Mantine, Species::Tyrogue,
                    Species::Hitmontop, Species::Larvitar, Species::Pupitar, Species::Tyranitar,
                    Species::Celebi, Species::Zigzagoon, Species::Linoone, Species::Lotad,
                    Species::Lombre, Species::Ludicolo, Species::Seedot, Species::Nuzleaf,
                    Species::Shiftry, Species::Wingull, Species::Pelipper, Species::Ralts,
                    Species::Kirlia, Species::Gardevoir, Species::Nincada, Species::Ninjask,
                    Species::Shedinja, Species::Sableye, Species::Mawile, Species::Electrike,
                    Species::Manectric, Species::Roselia, Species::Wailmer, Species::Wailord,
                    Species::Torkoal, Species::Trapinch, Species::Vibrava, Species::Flygon,
                    Species::Lunatone, Species::Solrock, Species::Barboach, Species::Whiscash,
                    Species::Corphish, Species::Crawdaunt, Species::Baltoy, Species::Claydol,
                    Species::Feebas, Species::Milotic, Species::Duskull, Species::Dusclops,
                    Species::Wynaut, Species::Snorunt, Species::Glalie, Species::Jirachi,
                    Species::Budew, Species::Roserade, Species::Combee, Species::Vespiquen,
                    Species::Cherubi, Species::Cherrim, Species::Shellos, Species::Gastrodon,
                    Species::Drifloon, Species::Drifblim, Species::Stunky, Species::Skuntank,
                    Species::Bronzor, Species::Bronzong, Species::Bonsly, Species::MimeJr,
                    Species::Munchlax, Species::Riolu, Species::Lucario, Species::Hippopotas,
                    Species::Hippowdon, Species::Skorupi, Species::Drapion, Species::Croagunk,
                    Species::Toxicroak, Species::Mantyke, Species::Snover, Species::Abomasnow,
                    Species::Weavile, Species::Rhyperior, Species::Togekiss, Species::Leafeon,
                    Species::Glaceon, Species::Mamoswine, Species::Gallade, Species::Dusknoir,
                    Species::Froslass, Species::Rotom, Species::Purrloin, Species::Liepard,
                    Species::Munna, Species::Musharna, Species::Pidove, Species::Tranquill,
                    Species::Unfezant, Species::Roggenrola, Species::Boldore, Species::Gigalith,
                    Species::Woobat, Species::Swoobat, Species::Drilbur, Species::Excadrill,
                    Species::Timburr, Species::Gurdurr, Species::Conkeldurr, Species::Tympole,
                    Species::Palpitoad, Species::Seismitoad, Species::Throh, Species::Sawk,
                    Species::Cottonee, Species::Whimsicott, Species::Basculin, Species::Darumaka,
                    Species::Darmanitan, Species::Maractus, Species::Dwebble, Species::Crustle,
                    Species::Scraggy, Species::Scrafty, Species::Sigilyph, Species::Yamask,
                    Species::Cofagrigus, Species::Trubbish, Species::Garbodor, Species::Minccino,
                    Species::Cinccino, Species::Gothita, Species::Gothorita, Species::Gothitelle,
                    Species::Solosis, Species::Duosion, Species::Reuniclus, Species::Vanillite,
                    Species::Vanillish, Species::Vanilluxe, Species::Karrablast,
                    Species::Escavalier, Species::Frillish, Species::Jellicent, Species::Joltik,
                    Species::Galvantula, Species::Ferroseed, Species::Ferrothorn, Species::Klink,
                    Species::Klang, Species::Klinklang, Species::Elgyem, Species::Beheeyem,
                    Species::Litwick, Species::Lampent, Species::Chandelure, Species::Axew,
                    Species::Fraxure, Species::Haxorus, Species::Cubchoo, Species::Beartic,
                    Species::Shelmet, Species::Accelgor, Species::Stunfisk, Species::Golett,
                    Species::Golurk, Species::Pawniard, Species::Bisharp, Species::Rufflet,
                    Species::Braviary, Species::Vullaby, Species::Mandibuzz, Species::Heatmor,
                    Species::Durant, Species::Deino, Species::Zweilous, Species::Hydreigon,
                    Species::Cobalion, Species::Terrakion, Species::Virizion, Species::Reshiram,
                    Species::Zekrom, Species::Kyurem, Species::Keldeo, Species::Bunnelby,
                    Species::Diggersby, Species::Pancham, Species::Pangoro, Species::Espurr,
                    Species::Meowstic, Species::Honedge, Species::Doublade, Species::Aegislash,
                    Species::Spritzee, Species::Aromatisse, Species::Swirlix, Species::Slurpuff,
                    Species::Inkay, Species::Malamar, Species::Binacle, Species::Barbaracle,
                    Species::Helioptile, Species::Heliolisk, Species::Sylveon, Species::Hawlucha,
                    Species::Goomy, Species::Sliggoo, Species::Goodra, Species::Phantump,
                    Species::Trevenant, Species::Pumpkaboo, Species::Gourgeist, Species::Bergmite,
                    Species::Avalugg, Species::Noibat, Species::Noivern, Species::Rowlet,
                    Species::Dartrix, Species::Decidueye, Species::Litten, Species::Torracat,
                    Species::Incineroar, Species::Popplio, Species::Brionne, Species::Primarina,
                    Species::Grubbin, Species::Charjabug, Species::Vikavolt, Species::Cutiefly,
                    Species::Ribombee, Species::Wishiwashi, Species::Mareanie, Species::Toxapex,
                    Species::Mudbray, Species::Mudsdale, Species::Dewpider, Species::Araquanid,
                    Species::Morelull, Species::Shiinotic, Species::Salandit, Species::Salazzle,
                    Species::Stufful, Species::Bewear, Species::Bounsweet, Species::Steenee,
                    Species::Tsareena, Species::Oranguru, Species::Passimian, Species::Wimpod,
                    Species::Golisopod, Species::Pyukumuku, Species::TypeNull, Species::Silvally,
                    Species::Turtonator, Species::Togedemaru, Species::Mimikyu, Species::Drampa,
                    Species::Dhelmise, Species::Jangmoo, Species::Hakamoo, Species::Kommoo,
                    Species::Cosmog, Species::Cosmoem, Species::Solgaleo, Species::Lunala,
                    Species::Necrozma, Species::Marshadow, Species::Zeraora, Species::Meltan,
                    Species::Melmetal, Species::Grookey, Species::Thwackey, Species::Rillaboom,
                    Species::Scorbunny, Species::Raboot, Species::Cinderace, Species::Sobble,
                    Species::Drizzile, Species::Inteleon, Species::Skwovet, Species::Greedent,
                    Species::Rookidee, Species::Corvisquire, Species::Corviknight, Species::Blipbug,
                    Species::Dottler, Species::Orbeetle, Species::Nickit, Species::Thievul,
                    Species::Gossifleur, Species::Eldegoss, Species::Wooloo, Species::Dubwool,
                    Species::Chewtle, Species::Drednaw, Species::Yamper, Species::Boltund,
                    Species::Rolycoly, Species::Carkol, Species::Coalossal, Species::Applin,
                    Species::Flapple, Species::Appletun, Species::Silicobra, Species::Sandaconda,
                    Species::Cramorant, Species::Arrokuda, Species::Barraskewda, Species::Toxel,
                    Species::Toxtricity, Species::Sizzlipede, Species::Centiskorch,
                    Species::Clobbopus, Species::Grapploct, Species::Sinistea, Species::Polteageist,
                    Species::Hatenna, Species::Hattrem, Species::Hatterene, Species::Impidimp,
                    Species::Morgrem, Species::Grimmsnarl, Species::Obstagoon, Species::Perrserker,
                    Species::Cursola, Species::Sirfetchd, Species::MrRime, Species::Runerigus,
                    Species::Milcery, Species::Alcremie, Species::Falinks, Species::Pincurchin,
                    Species::Snom, Species::Frosmoth, Species::Stonjourner, Species::Eiscue,
                    Species::Indeedee, Species::Morpeko, Species::Cufant, Species::Copperajah,
                    Species::Dracozolt, Species::Arctozolt, Species::Dracovish, Species::Arctovish,
                    Species::Duraludon, Species::Dreepy, Species::Drakloak, Species::Dragapult,
                    Species::Zacian, Species::Zamazenta, Species::Eternatus,

                    // Isle of Armor
                    Species::Sandshrew, Species::Sandslash, Species::Jigglypuff,
                    Species::Wigglytuff, Species::Psyduck, Species::Golduck, Species::Poliwag,
                    Species::Poliwhirl, Species::Poliwrath, Species::Abra, Species::Kadabra,
                    Species::Alakazam, Species::Tentacool, Species::Tentacruel, Species::Slowpoke,
                    Species::Slowbro, Species::Magnemite, Species::Magneton, Species::Exeggcute,
                    Species::Exeggutor, Species::Cubone, Species::Marowak, Species::Lickitung,
                    Species::Chansey, Species::Tangela, Species::Kangaskhan, Species::Horsea,
                    Species::Seadra, Species::Staryu, Species::Starmie, Species::Scyther,
                    Species::Pinsir, Species::Tauros, Species::Igglybuff, Species::Marill,
                    Species::Azumarill, Species::Politoed, Species::Slowking, Species::Dunsparce,
                    Species::Scizor, Species::Heracross, Species::Skarmory, Species::Kingdra,
                    Species::Porygon2, Species::Miltank, Species::Blissey, Species::Whismur,
                    Species::Loudred, Species::Exploud, Species::Azurill, Species::Carvanha,
                    Species::Sharpedo, Species::Shinx, Species::Luxio, Species::Luxray,
                    Species::Buneary, Species::Lopunny, Species::Happiny, Species::Magnezone,
                    Species::Lickilicky, Species::Tangrowth, Species::PorygonZ, Species::Lillipup,
                    Species::Herdier, Species::Stoutland, Species::Venipede, Species::Whirlipede,
                    Species::Scolipede, Species::Petilil, Species::Lilligant, Species::Sandile,
                    Species::Krokorok, Species::Krookodile, Species::Zorua, Species::Zoroark,
                    Species::Emolga, Species::Foongus, Species::Amoonguss, Species::Mienfoo,
                    Species::Mienshao, Species::Druddigon, Species::Bouffalant, Species::Larvesta,
                    Species::Volcarona, Species::Fletchling, Species::Fletchinder,
                    Species::Talonflame, Species::Skrelp, Species::Dragalge, Species::Clauncher,
                    Species::Clawitzer, Species::Dedenne, Species::Klefki, Species::Rockruff,
                    Species::Lycanroc, Species::Fomantis, Species::Lurantis, Species::Comfey,
                    Species::Sandygast, Species::Palossand, Species::Magearna, Species::Kubfu,
                    Species::Urshifu, Species::Zarude,

                    // Crown Tundra
                    Species::Regieleki, Species::Regidrago, Species::Glastrier, Species::Spectrier,
                    Species::Calyrex, Species::Articuno, Species::Zapdos, Species::Moltres,
                    Species::Slowking, Species::NidoranF, Species::Nidorina, Species::Nidoqueen,
                    Species::NidoranM, Species::Nidorino, Species::Nidoking, Species::Zubat,
                    Species::Golbat, Species::Jynx, Species::Electabuzz, Species::Magmar,
                    Species::Omanyte, Species::Omastar, Species::Kabuto, Species::Kabutops,
                    Species::Aerodactyl, Species::Dratini, Species::Dragonair, Species::Dragonite,
                    Species::Crobat, Species::Smoochum, Species::Elekid, Species::Magby,
                    Species::Raikou, Species::Entei, Species::Suicune, Species::Lugia,
                    Species::HoOh, Species::Treecko, Species::Grovyle, Species::Sceptile,
                    Species::Torchic, Species::Combusken, Species::Blaziken, Species::Mudkip,
                    Species::Marshtomp, Species::Swampert, Species::Aron, Species::Lairon,
                    Species::Aggron, Species::Swablu, Species::Altaria, Species::Lileep,
                    Species::Cradily, Species::Anorith, Species::Armaldo, Species::Absol,
                    Species::Spheal, Species::Sealeo, Species::Walrein, Species::Relicanth,
                    Species::Bagon, Species::Shelgon, Species::Salamence, Species::Beldum,
                    Species::Metang, Species::Metagross, Species::Regirock, Species::Regice,
                    Species::Registeel, Species::Latias, Species::Latios, Species::Kyogre,
                    Species::Groudon, Species::Rayquaza, Species::Spiritomb, Species::Gible,
                    Species::Gabite, Species::Garchomp, Species::Electivire, Species::Magmortar,
                    Species::Uxie, Species::Mesprit, Species::Azelf, Species::Dialga,
                    Species::Palkia, Species::Heatran, Species::Regigigas, Species::Giratina,
                    Species::Cresselia, Species::Victini, Species::Audino, Species::Tirtouga,
                    Species::Carracosta, Species::Archen, Species::Archeops, Species::Cryogonal,
                    Species::Tornadus, Species::Thundurus, Species::Landorus, Species::Genesect,
                    Species::Tyrunt, Species::Tyrantrum, Species::Amaura, Species::Aurorus,
                    Species::Carbink, Species::Xerneas, Species::Yveltal, Species::Zygarde,
                    Species::Diancie, Species::Volcanion, Species::TapuKoko, Species::TapuLele,
                    Species::TapuBulu, Species::TapuFini, Species::Nihilego, Species::Buzzwole,
                    Species::Pheromosa, Species::Xurkitree, Species::Celesteela, Species::Kartana,
                    Species::Guzzlord, Species::Poipole, Species::Naganadel, Species::Stakataka,
                    Species::Blacephalon};
                return items;
            }
            case GameVersion::SL:
            case GameVersion::VL:
            {
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        std::set<Species> ret;
                        for (u16 i = 1; i <= u16(Species::Pecharunt); i++)
                        {
                            if (PersonalSV::isPresentInGame(i))
                            {
                                ret.emplace(Species{i});
                            }
                        }
                        return ret;
                    });
                return items;
            }
            case GameVersion::ZA:
            {
                // Built from personal_za IsPresentInGame flag at offset 0x1C
                static const std::set<Species> items = std::invoke(
                    []()
                    {
                        std::set<Species> ret;
                        for (u16 i = 1; i <= u16(Species::Pecharunt); i++)
                        {
                            if (PersonalZA::isPresentInGame(i))
                            {
                                ret.emplace(Species{i});
                            }
                        }
                        return ret;
                    });
                return items;
            }
            case GameVersion::PLA:
            {
                static const std::set<Species> items = {Species::Pikachu, Species::Raichu,
                    Species::Clefairy, Species::Clefable, Species::Vulpix, Species::Ninetales,
                    Species::Zubat, Species::Golbat, Species::Paras, Species::Parasect,
                    Species::Psyduck, Species::Golduck, Species::Growlithe, Species::Arcanine,
                    Species::Abra, Species::Kadabra, Species::Alakazam, Species::Machop,
                    Species::Machoke, Species::Machamp, Species::Tentacool, Species::Tentacruel,
                    Species::Geodude, Species::Graveler, Species::Golem, Species::Ponyta,
                    Species::Rapidash, Species::Magnemite, Species::Magneton, Species::Gastly,
                    Species::Haunter, Species::Gengar, Species::Onix, Species::Voltorb,
                    Species::Electrode, Species::Lickitung, Species::Rhyhorn, Species::Rhydon,
                    Species::Chansey, Species::Tangela, Species::MrMime, Species::Scyther,
                    Species::Electabuzz, Species::Magmar, Species::Magikarp, Species::Gyarados,
                    Species::Eevee, Species::Vaporeon, Species::Jolteon, Species::Flareon,
                    Species::Porygon, Species::Snorlax, Species::Cyndaquil, Species::Quilava,
                    Species::Typhlosion, Species::Crobat, Species::Pichu, Species::Cleffa,
                    Species::Togepi, Species::Togetic, Species::Sudowoodo, Species::Aipom,
                    Species::Yanma, Species::Espeon, Species::Umbreon, Species::Murkrow,
                    Species::Misdreavus, Species::Unown, Species::Gligar, Species::Steelix,
                    Species::Qwilfish, Species::Scizor, Species::Heracross, Species::Sneasel,
                    Species::Teddiursa, Species::Ursaring, Species::Swinub, Species::Piloswine,
                    Species::Remoraid, Species::Octillery, Species::Mantine, Species::Porygon2,
                    Species::Stantler, Species::Elekid, Species::Magby, Species::Blissey,
                    Species::Wurmple, Species::Silcoon, Species::Beautifly, Species::Cascoon,
                    Species::Dustox, Species::Ralts, Species::Kirlia, Species::Gardevoir,
                    Species::Nosepass, Species::Roselia, Species::Barboach, Species::Whiscash,
                    Species::Duskull, Species::Dusclops, Species::Chimecho, Species::Snorunt,
                    Species::Glalie, Species::Spheal, Species::Sealeo, Species::Walrein,
                    Species::Turtwig, Species::Grotle, Species::Torterra, Species::Chimchar,
                    Species::Monferno, Species::Infernape, Species::Piplup, Species::Prinplup,
                    Species::Empoleon, Species::Starly, Species::Staravia, Species::Staraptor,
                    Species::Bidoof, Species::Bibarel, Species::Kricketot, Species::Kricketune,
                    Species::Shinx, Species::Luxio, Species::Luxray, Species::Budew,
                    Species::Roserade, Species::Cranidos, Species::Rampardos, Species::Shieldon,
                    Species::Bastiodon, Species::Burmy, Species::Wormadam, Species::Mothim,
                    Species::Combee, Species::Vespiquen, Species::Pachirisu, Species::Buizel,
                    Species::Floatzel, Species::Cherubi, Species::Cherrim, Species::Shellos,
                    Species::Gastrodon, Species::Ambipom, Species::Drifloon, Species::Drifblim,
                    Species::Buneary, Species::Lopunny, Species::Mismagius, Species::Honchkrow,
                    Species::Glameow, Species::Purugly, Species::Chingling, Species::Stunky,
                    Species::Skuntank, Species::Bronzor, Species::Bronzong, Species::Bonsly,
                    Species::MimeJr, Species::Happiny, Species::Chatot, Species::Spiritomb,
                    Species::Gible, Species::Gabite, Species::Garchomp, Species::Munchlax,
                    Species::Riolu, Species::Lucario, Species::Hippopotas, Species::Hippowdon,
                    Species::Skorupi, Species::Drapion, Species::Croagunk, Species::Toxicroak,
                    Species::Carnivine, Species::Finneon, Species::Lumineon, Species::Mantyke,
                    Species::Snover, Species::Abomasnow, Species::Weavile, Species::Magnezone,
                    Species::Lickilicky, Species::Rhyperior, Species::Tangrowth,
                    Species::Electivire, Species::Magmortar, Species::Togekiss, Species::Yanmega,
                    Species::Leafeon, Species::Glaceon, Species::Gliscor, Species::Mamoswine,
                    Species::PorygonZ, Species::Gallade, Species::Probopass, Species::Dusknoir,
                    Species::Froslass, Species::Rotom, Species::Uxie, Species::Mesprit,
                    Species::Azelf, Species::Dialga, Species::Palkia, Species::Heatran,
                    Species::Regigigas, Species::Giratina, Species::Cresselia, Species::Phione,
                    Species::Manaphy, Species::Darkrai, Species::Shaymin, Species::Arceus,
                    Species::Oshawott, Species::Dewott, Species::Samurott, Species::Petilil,
                    Species::Lilligant, Species::Basculin, Species::Zorua, Species::Zoroark,
                    Species::Rufflet, Species::Braviary, Species::Tornadus, Species::Thundurus,
                    Species::Landorus, Species::Sylveon, Species::Goomy, Species::Sliggoo,
                    Species::Goodra, Species::Bergmite, Species::Avalugg, Species::Rowlet,
                    Species::Dartrix, Species::Decidueye, Species::Wyrdeer, Species::Kleavor,
                    Species::Ursaluna, Species::Basculegion, Species::Sneasler, Species::Overqwil,
                    Species::Enamorus};
                return items;
            }
            default:
                return emptySet;
        }
    }

    const std::set<Ability>& VersionTables::availableAbilities(GameVersion version)
    {
        static const std::set<Ability> emptySet;
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
            {
                static const std::set<Ability> items = {Ability::None};
                return items;
            }
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
            {
                static const std::set<Ability> items = {Ability::None};
                return items;
            }
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(
                            Ability::Stench, Ability::TangledFeet);
                    });
                return items;
            }
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(Ability::Stench, Ability::BadDreams);
                    });
                return items;
            }
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(Ability::Stench, Ability::Teravolt);
                    });
                return items;
            }
            case GameVersion::X:
            case GameVersion::Y:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(Ability::Stench, Ability::AuraBreak);
                    });
                return items;
            }
            case GameVersion::OR:
            case GameVersion::AS:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(
                            Ability::Stench, Ability::DeltaStream);
                    });
                return items;
            }
            case GameVersion::SN:
            case GameVersion::MN:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(
                            Ability::Stench, Ability::PrismArmor);
                    });
                return items;
            }
            case GameVersion::US:
            case GameVersion::UM:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(
                            Ability::Stench, Ability::FireMane);
                    });
                return items;
            }
            case GameVersion::GE:
            case GameVersion::GP:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(
                            Ability::Stench, Ability::Neuroforce);
                    });
                return items;
            }
            case GameVersion::SW:
            case GameVersion::SH:
            case GameVersion::PLA:
            case GameVersion::SL:
            case GameVersion::VL:
            case GameVersion::ZA:
            {
                static const std::set<Ability> items = std::invoke(
                    []()
                    {
                        return create_set_consecutive<Ability>(Ability::Stench, Ability::AsOneG);
                    }); // AsOneG for all these games
                return items;
            }
            default:
                return emptySet;
        }
    }

    const std::set<Ball>& VersionTables::availableBalls(GameVersion version)
    {
        static const std::set<Ball> emptySet;
        if (version == GameVersion::PLA)
        {
            static const std::set<Ball> items = std::invoke(
                []() { return create_set_consecutive<Ball>(Ball::Master, Ball::LAOrigin); });
            return items;
        }
        if (version == GameVersion::SL || version == GameVersion::VL || version == GameVersion::ZA)
        {
            static const std::set<Ball> items = std::invoke(
                []()
                {
                    return create_set_consecutive<Ball>(Ball::Master, Ball::Beast);
                }); // LAOrigin exists in these games too technically, but Beast for now
            return items;
        }
        switch ((Generation)version)
        {
            case Generation::ONE:
            {
                static const std::set<Ball> items = std::invoke(
                    []() { return create_set_consecutive<Ball>(Ball::Master, Ball::Safari); });
                return items;
            }
            case Generation::TWO:
            {
                static const std::set<Ball> items = {Ball::Master, Ball::Ultra, Ball::Great,
                    Ball::Poke, Ball::Safari, Ball::Fast, Ball::Level, Ball::Lure, Ball::Heavy,
                    Ball::Love, Ball::Friend, Ball::Moon};
                return items;
            }
            case Generation::THREE:
            {
                static const std::set<Ball> items = std::invoke(
                    []() { return create_set_consecutive<Ball>(Ball::Master, Ball::Premier); });
                return items;
            }
            case Generation::FOUR:
            {
                static const std::set<Ball> items = std::invoke(
                    []() { return create_set_consecutive<Ball>(Ball::Master, Ball::Sport); });
                return items;
            }
            case Generation::FIVE:
            case Generation::SIX:
            {
                static const std::set<Ball> items = std::invoke(
                    []() { return create_set_consecutive<Ball>(Ball::Master, Ball::Dream); });
                return items;
            }
            case Generation::SEVEN:
            case Generation::LGPE:
            case Generation::EIGHT:
            {
                static const std::set<Ball> items = std::invoke(
                    []() { return create_set_consecutive<Ball>(Ball::Master, Ball::Beast); });
                return items;
            }
            default:
                return emptySet;
        }
    }

    int VersionTables::maxItem(GameVersion version)
    {
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
                return 250;
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
                return 249;
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
                return 374;
            case GameVersion::D:
            case GameVersion::P:
                return 464;
            case GameVersion::Pt:
                return 467;
            case GameVersion::HG:
            case GameVersion::SS:
                return 536;
            case GameVersion::B:
            case GameVersion::W:
                return 632;
            case GameVersion::B2:
            case GameVersion::W2:
                return 638;
            case GameVersion::X:
            case GameVersion::Y:
                return 717;
            case GameVersion::OR:
            case GameVersion::AS:
                return 775;
            case GameVersion::SN:
            case GameVersion::MN:
                return 920;
            case GameVersion::US:
            case GameVersion::UM:
                return 1023;
            case GameVersion::GE:
            case GameVersion::GP:
                return 1057;
            case GameVersion::SW:
            case GameVersion::SH:
                return 1607;
            case GameVersion::PLA:
                return 1828;
            case GameVersion::SL:
            case GameVersion::VL:
                return 2557;
            case GameVersion::ZA:
                return 2684;
            default:
                return 0;
        }
    }

    Move VersionTables::maxMove(GameVersion version)
    {
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
                return Move::Substitute; // technically it's Struggle
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
                return Move::BeatUp;
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
                return Move::PsychoBoost;
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
                return Move::ShadowForce;
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
                return Move::FusionBolt;
            case GameVersion::X:
            case GameVersion::Y:
                return Move::LightofRuin;
            case GameVersion::OR:
            case GameVersion::AS:
                return Move::HyperspaceFury;
            case GameVersion::SN:
            case GameVersion::MN:
                return Move::MindBlown;
            case GameVersion::US:
            case GameVersion::UM:
                return Move::NihilLight;
            case GameVersion::GE:
            case GameVersion::GP:
                return Move::DoubleIronBash;
            case GameVersion::SW:
            case GameVersion::SH:
                return Move::EerieSpell;
            case GameVersion::PLA:
                return Move::TakeHeart;
            case GameVersion::SL:
            case GameVersion::VL:
                return Move::MalignantChain;
            case GameVersion::ZA:
                return Move::NihilLight;
            default:
                return Move::None;
        }
    }

    Species VersionTables::maxSpecies(GameVersion version)
    {
        switch (version)
        {
            case GameVersion::RD:
            case GameVersion::GN:
            case GameVersion::BU:
            case GameVersion::YW:
                return Species::Mew;
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
                return Species::Celebi;
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
                return Species::Deoxys;
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
                return Species::Arceus;
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
                return Species::Genesect;
            case GameVersion::X:
            case GameVersion::Y:
            case GameVersion::OR:
            case GameVersion::AS:
                return Species::Volcanion;
            case GameVersion::SN:
            case GameVersion::MN:
                return Species::Marshadow;
            case GameVersion::US:
            case GameVersion::UM:
                return Species::Pecharunt;
            case GameVersion::GE:
            case GameVersion::GP:
                return Species::Melmetal;
            case GameVersion::SW:
            case GameVersion::SH:
                return Species::Calyrex;
            case GameVersion::PLA:
                return Species::Enamorus;
            case GameVersion::SL:
            case GameVersion::VL:
            case GameVersion::ZA:
                return Species::Pecharunt;
            default:
                return Species::None;
        }
    }

    Ability VersionTables::maxAbility(GameVersion version)
    {
        switch (version)
        {
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
                return Ability::TangledFeet;
            case GameVersion::D:
            case GameVersion::P:
            case GameVersion::Pt:
            case GameVersion::HG:
            case GameVersion::SS:
                return Ability::BadDreams;
            case GameVersion::B:
            case GameVersion::W:
            case GameVersion::B2:
            case GameVersion::W2:
                return Ability::Teravolt;
            case GameVersion::X:
            case GameVersion::Y:
                return Ability::AuraBreak;
            case GameVersion::OR:
            case GameVersion::AS:
                return Ability::DeltaStream;
            case GameVersion::SN:
            case GameVersion::MN:
                return Ability::PrismArmor;
            case GameVersion::US:
            case GameVersion::UM:
                return Ability::FireMane;
            case GameVersion::GE:
            case GameVersion::GP:
                return Ability::Neuroforce;
            case GameVersion::SW:
            case GameVersion::SH:
            case GameVersion::PLA:
            case GameVersion::SL:
            case GameVersion::VL:
            case GameVersion::ZA:
                return Ability::AsOneG; // supposedly also AsOneG for all these
            default:
                return Ability::None;
        }
    }

    Ball VersionTables::maxBall(GameVersion version)
    {
        if (version == GameVersion::PLA)
        {
            return Ball::LAOrigin;
        }
        if (version == GameVersion::SL || version == GameVersion::VL || version == GameVersion::ZA)
        {
            return Ball::Beast;
        }
        switch ((Generation)version)
        {
            case Generation::ONE:
                return Ball::Safari;
            case Generation::TWO:
                return Ball::Moon;
            case Generation::THREE:
                return Ball::Premier;
            case Generation::FOUR:
                return Ball::Sport;
            case Generation::FIVE:
            case Generation::SIX:
                return Ball::Dream;
            case Generation::SEVEN:
            case Generation::LGPE:
                return Ball::Beast;
            case Generation::EIGHT:
                return Ball::Beast;
            default:
                return Ball::None;
        }
    }

    u8 VersionTables::formCount(GameVersion version, Species species)
    {
        switch (version)
        {
            case GameVersion::GD:
            case GameVersion::SV:
            case GameVersion::C:
                return PersonalGSC::formCount(u16(species));
            case GameVersion::R:
            case GameVersion::S:
            case GameVersion::FR:
            case GameVersion::LG:
            case GameVersion::E:
                return PersonalRSFRLGE::formCount(u16(species));
            case GameVersion::D:
            case GameVersion::P:
                if (species == Species::Rotom || species == Species::Giratina ||
                    species == Species::Shaymin)
                {
                    return 1;
                }
            // falls through
            case GameVersion::Pt:
                if (species == Species::Pichu)
                {
                    return 1;
                }
                // falls through
            case GameVersion::HG:
            case GameVersion::SS:
                return PersonalDPPtHGSS::formCount(u16(species));
            case GameVersion::B:
            case GameVersion::W:
                if (species == Species::Tornadus || species == Species::Thundurus ||
                    species == Species::Landorus || species == Species::Kyurem ||
                    species == Species::Keldeo)
                {
                    return 1;
                }
            // falls through
            case GameVersion::B2:
            case GameVersion::W2:
                return PersonalBWB2W2::formCount(u16(species));
            case GameVersion::X:
            case GameVersion::Y:
                if (species == Species::Beedrill || species == Species::Pidgeot ||
                    species == Species::Pikachu || species == Species::Slowbro ||
                    species == Species::Steelix || species == Species::Sceptile ||
                    species == Species::Swampert || species == Species::Sableye ||
                    species == Species::Sharpedo || species == Species::Camerupt ||
                    species == Species::Altaria || species == Species::Glalie ||
                    species == Species::Salamence || species == Species::Metagross ||
                    species == Species::Kyogre || species == Species::Groudon ||
                    species == Species::Rayquaza || species == Species::Lopunny ||
                    species == Species::Gallade || species == Species::Audino ||
                    species == Species::Hoopa || species == Species::Diancie)
                {
                    return 1;
                }
                // falls through
            case GameVersion::OR:
            case GameVersion::AS:
                return PersonalXYORAS::formCount(u16(species));
            case GameVersion::SN:
            case GameVersion::MN:
                if (species == Species::Lycanroc)
                {
                    return 2;
                }
                if (species == Species::Pikachu)
                {
                    return 7;
                }
                if (species == Species::Necrozma || species == Species::Ribombee ||
                    species == Species::Araquanid || species == Species::Togedemaru)
                {
                    return 1;
                }
                if (species == Species::Marowak)
                {
                    return 2;
                }
                // falls through
            case GameVersion::US:
            case GameVersion::UM:
                return PersonalSMUSUM::formCount(u16(species));
            case GameVersion::GE:
            case GameVersion::GP:
                return PersonalLGPE::formCount(u16(species));
            case GameVersion::SW:
            case GameVersion::SH:
                return PersonalSWSH::formCount(u16(species));
            case GameVersion::PLA:
                return PersonalPLA::formCount(u16(species));
            case GameVersion::SL:
            case GameVersion::VL:
                return PersonalSV::formCount(u16(species));
            case GameVersion::ZA:
                return PersonalZA::formCount(u16(species));
            default:
                return 1;
        }
    }

    u8 VersionTables::movePP(pksm::Generation gen, Move move, u8 ppUps)
    {
        if (move == pksm::Move::INVALID || move == pksm::Move::None ||
            size_t(move) >= internal::PP_G8.size())
        {
            return 0;
        }
        u8 val = 0;
        switch (gen)
        {
            case pksm::Generation::NINE:
            case pksm::Generation::EIGHT:
            case pksm::Generation::SEVEN:
                val = internal::PP_G8[size_t(move)];
                break;
            case pksm::Generation::SIX:
            {
                auto found = std::find_if(internal::PPDiff_G6.begin(), internal::PPDiff_G6.end(),
                    [move](const std::pair<pksm::Move, u8>& v) { return v.first == move; });
                if (found != internal::PPDiff_G6.end())
                {
                    val = found->second;
                }
                else
                {
                    val = internal::PP_G8[size_t(move)];
                }
            }
            break;
            case pksm::Generation::FIVE:
            {
                auto found = std::find_if(internal::PPDiff_G5.begin(), internal::PPDiff_G5.end(),
                    [move](const std::pair<pksm::Move, u8>& v) { return v.first == move; });
                if (found != internal::PPDiff_G5.end())
                {
                    val = found->second;
                }
                else
                {
                    val = internal::PP_G8[size_t(move)];
                }
            }
            break;
            case pksm::Generation::FOUR:
            {
                auto found = std::find_if(internal::PPDiff_G4.begin(), internal::PPDiff_G4.end(),
                    [move](const std::pair<pksm::Move, u8>& v) { return v.first == move; });
                if (found != internal::PPDiff_G4.end())
                {
                    val = found->second;
                }
                else
                {
                    val = internal::PP_G8[size_t(move)];
                }
            }
            break;
            // So... no PP changes for Gen I and II moves occurred until Gen IV. Nice.
            case pksm::Generation::ONE:
            case pksm::Generation::TWO:
            case pksm::Generation::THREE:
            {
                auto found =
                    std::find_if(internal::PPDiff_G123.begin(), internal::PPDiff_G123.end(),
                        [move](const std::pair<pksm::Move, u8>& v) { return v.first == move; });
                if (found != internal::PPDiff_G123.end())
                {
                    val = found->second;
                }
                else
                {
                    val = internal::PP_G8[size_t(move)];
                }
            }
            break;
            case pksm::Generation::LGPE:
            {
                auto found =
                    std::find_if(internal::PPDiff_LGPE.begin(), internal::PPDiff_LGPE.end(),
                        [move](const std::pair<pksm::Move, u8>& v) { return v.first == move; });
                if (found != internal::PPDiff_LGPE.end())
                {
                    val = found->second;
                }
                else
                {
                    val = internal::PP_G8[size_t(move)];
                }
            }
            break;
            default:
                return 0;
        }

        // Stupid thing G1/2 does: they can't store above 63 for PP value
        if (gen <= pksm::Generation::TWO && val == 40)
        {
            return val + 7 * ppUps;
        }
        return val + ((val / 5) * ppUps);
    }
}
