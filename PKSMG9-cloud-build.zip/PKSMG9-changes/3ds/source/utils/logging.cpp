/*
 *   This file is part of PKSM
 *   Copyright (C) 2016-2025 Bernardo Giordano, Admiral Fish, piepie62
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Additional Terms 7.b and 7.c of GPLv3 apply to this file:
 *       * Requiring preservation of specified reasonable legal notices or
 *         author attributions in that material or in the Appropriate Legal
 *         Notices displayed by works containing it.
 *       * Prohibiting misrepresentation of the origin of that material,
 *         or requiring that modified versions of such material be marked in
 *         reasonable ways as different from the original version.
 */

#include "logging.hpp"
#include "font.h"

#if defined(__3DS__)
#include <3ds.h>
#endif

#include "revision.h"
#include "server.hpp"
#include <chrono>
#include <cstring>
#include <iomanip>
#include <mutex>
#include <sstream>

namespace
{
    std::string applicationLogs;
    PrintConsole headerConsole; // Fixed header console
    PrintConsole logConsole;    // Scrolling log console
    std::chrono::steady_clock::time_point startTime;
    std::string logFilePath;

    // False while the GUI owns the bottom screen, and once gfx is gone for good.
    bool consoleAttached = false;

    std::mutex logMutex;
    constexpr size_t LOG_BUFFER_SIZE = 8192;
    // applicationLogs is only what /logs/memory serves; the file on the SD card is
    // the complete record. Title and save scanning emits one entry per title, so an
    // uncapped buffer grows with the size of the user's SD card. Keep the tail.
    constexpr size_t MEMORY_LOG_MAX = 128 * 1024;
    std::string logBuffer;
    FILE* logFile = nullptr;

    // Caller must hold logMutex.
    void trimMemoryLog()
    {
        if (applicationLogs.size() <= MEMORY_LOG_MAX)
        {
            return;
        }
        // Drop the oldest quarter, rounded forward to a line boundary so the
        // served text never starts mid-entry.
        size_t cut = applicationLogs.size() - (MEMORY_LOG_MAX * 3 / 4);
        cut        = applicationLogs.find('\n', cut);
        applicationLogs.erase(0, cut == std::string::npos ? applicationLogs.size() : cut + 1);
    }

    std::string versionInfo()
    {
        return std::format(
            "PKSM v{:d}.{:d}.{:d}-{:s}", VERSION_MAJOR, VERSION_MINOR, VERSION_MICRO, GIT_REV);
    }

    void flushLogBuffer()
    {
        if (logBuffer.empty())
        {
            return;
        }
        if (logFile != NULL)
        {
            fwrite(logBuffer.data(), 1, logBuffer.size(), logFile);
            fflush(logFile);
            logBuffer.clear();
        }
    }
}

void Logging::attachConsole()
{
    consoleInit(GFX_BOTTOM, &headerConsole);
    consoleInit(GFX_BOTTOM, &logConsole);

    // libctru counts window rows and columns from 1, and consoleSetWindow silently clamps a
    // 0 up to 1: asking for row 0 put the log window on top of the header instead of under
    // it, which cost the version line and left the bottom row of the screen unused.
    consoleSetWindow(&headerConsole, 1, 1, 40, 1); // the top line, nothing else
    consoleSetWindow(&logConsole, 1, 2, 40, 29);   // the other 29, down to the last one

    ConsoleFont font;
    font.gfx         = (u8*)console_font_8x8;
    font.asciiOffset = 0;
    font.numChars    = 255;

    consoleSetFont(&headerConsole, &font);
    consoleSetFont(&logConsole, &font);

    consoleAttached = true;

    std::string version = versionInfo();
    consoleSelect(&headerConsole);
    printf("\x1b[1;%dH" CONSOLE_YELLOW "%s" CONSOLE_RESET, 41 - static_cast<int>(version.length()),
        version.c_str());
    consoleSelect(&logConsole);
    gfxFlushBuffers();
}

void Logging::detachConsole()
{
    consoleAttached = false;
}

void Logging::init()
{
    startTime = std::chrono::steady_clock::now();

    attachConsole();

    // Get current date for log filename
    auto now        = std::chrono::system_clock::now();
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    std::tm* now_tm = std::localtime(&now_time_t);

    char dateBuf[9];
    std::strftime(dateBuf, sizeof(dateBuf), "%Y%m%d", now_tm);

#if defined(__3DS__)
    logFilePath = std::string("sdmc:/3ds/PKSMG9/logs/pksm_") + dateBuf + ".log";
#elif defined(__SWITCH__)
    logFilePath = std::string("/switch/PKSM/logs/pksm_") + dateBuf + ".log";
#else
    logFilePath = std::string("pksm_") + dateBuf + ".log";
#endif

    logBuffer.reserve(LOG_BUFFER_SIZE);

    info(versionInfo());

    Server::registerHandler("/logs/memory",
        [](const std::string& path, const std::string& requestData) -> Server::HttpResponse
        {
            // Served from a server thread while log() may be appending.
            std::lock_guard<std::mutex> lock(logMutex);
            return {200, "text/plain", applicationLogs};
        });

    Server::registerHandler("/logs/file",
        [](const std::string& path, const std::string& requestData) -> Server::HttpResponse
        {
            std::lock_guard<std::mutex> lock(logMutex);
            flushLogBuffer();

            FILE* readFile = fopen(logFilePath.c_str(), "r");
            if (readFile == nullptr)
            {
                return {404, "text/plain", "Log file not found"};
            }

            fseek(readFile, 0, SEEK_END);
            long fileSize = ftell(readFile);
            fseek(readFile, 0, SEEK_SET);

            std::string logData;
            logData.resize(fileSize);
            fread(logData.data(), 1, fileSize, readFile);
            fclose(readFile);

            return {200, "text/plain", logData};
        });
}

void Logging::startupLog(const std::string& category, const std::string& message)
{
    std::chrono::steady_clock::time_point currentTime = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed             = currentTime - startTime;
    double seconds                                    = elapsed.count();

    std::ostringstream oss;
    oss << "[" << std::setw(3) << std::setfill(' ') << (int)seconds << "." << std::setfill('0')
        << std::setw(4) << (int)((seconds - (int)seconds) * 10000 + 0.5) << "]";
    std::string formattedText = oss.str() + " " + category + ": " + message;
    info(category + ": " + message);

    if (!consoleAttached)
    {
        return;
    }

    consoleSelect(&logConsole);
    printf("%s\n", formattedText.c_str());
}

void Logging::info(const std::string& message)
{
    log(LogLevel::INFO, message);
}

void Logging::warning(const std::string& message)
{
    log(LogLevel::WARN, message);
}

void Logging::error(const std::string& message)
{
    log(LogLevel::ERROR, message);
}

void Logging::debug(const std::string& message)
{
    log(LogLevel::DEBUG, message);
}

void Logging::trace(const std::string& message)
{
    log(LogLevel::TRACE, message);
}

void Logging::log(LogLevel level, const std::string& message)
{
    std::stringstream ss;
    auto now        = std::chrono::system_clock::now();
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    auto now_ms =
        std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;

    ss << std::put_time(std::localtime(&now_time_t), "[%Y-%m-%d %H:%M:%S");
    ss << "." << std::setfill('0') << std::setw(3) << now_ms.count() << "]";

    switch (level)
    {
        case LogLevel::TRACE:
            ss << " TRACE - ";
            break;
        case LogLevel::DEBUG:
            ss << " DEBUG - ";
            break;
        case LogLevel::INFO:
            ss << "  INFO - ";
            break;
        case LogLevel::WARN:
            ss << "  WARN - ";
            break;
        case LogLevel::ERROR:
            ss << " ERROR - ";
            break;
    }

    std::string logEntry = ss.str() + message + "\n";

    std::lock_guard<std::mutex> lock(logMutex);
    applicationLogs += logEntry;
    trimMemoryLog();
    logBuffer += logEntry;

    // Flush if buffer is getting full or for important messages
    if (logFile != nullptr)
    {
        if (logBuffer.size() >= LOG_BUFFER_SIZE || level == LogLevel::ERROR ||
            level == LogLevel::WARN)
        {
            flushLogBuffer();
        }
    }
}

void Logging::initFileLogging()
{
    logFile = fopen(logFilePath.c_str(), "a");
}

void Logging::exit()
{
    std::lock_guard<std::mutex> lock(logMutex);
    flushLogBuffer();
    if (logFile != nullptr)
    {
        fclose(logFile);
        // Teardown carries on logging after this point, and flushLogBuffer writes to
        // whatever this holds.
        logFile = nullptr;
    }
}
